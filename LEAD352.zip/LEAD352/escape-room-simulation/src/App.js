import React from 'react';
import EscapeRoomSimulation from './components/EscapeRoomSimulation';

function App() {
  return (
    <div className="App" style={{ padding: '20px' }}>
      <EscapeRoomSimulation />
    </div>
  );
}

export default App;