import React, { useState, useCallback, useMemo } from "react";
import { Button, Card, CardContent, Typography } from "@mui/material";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, Cell } from "recharts";

const personalityTraits = ["Openness", "Conscientiousness", "Extraversion", "Agreeableness", "Neuroticism"];
const discussionTasks = [
  { name: "Describe the clue found and propose interpretations", favoredTrait: "Openness" },
  { name: "Discuss potential solutions for the lock mechanism based on available clues", favoredTrait: "Conscientiousness" },
  { name: "Plan the next sequence of actions based on the group's understanding", favoredTrait: "Agreeableness" },
  { name: "Facilitate creative brainstorming for alternative solutions", favoredTrait: "Openness" },
  { name: "Summarize group decisions and ensure shared understanding", favoredTrait: "Conscientiousness" },
  { name: "Reflect on team collaboration and adjust communication strategies", favoredTrait: "Agreeableness" }
];

// ... existing code from Team_project.js ...

export default function EscapeRoomSimulation() {
  const [simulationIndex, setSimulationIndex] = useState(0);
  const [results, setResults] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  // ... rest of the component code from Team_project.js ...
}