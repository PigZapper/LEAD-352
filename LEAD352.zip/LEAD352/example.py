import os
from dotenv import load_dotenv
import sys
from datetime import datetime
# Import necessary libraries
from crewai import Agent, Task, Crew
from langchain_community.llms import Ollama  # Updated import path

# Load environment variables from .env file (keeping this for potential future use)
load_dotenv()

# Set up the LLM using Ollama
custom_llm = Ollama(model="llama3:8b")

# === AGENTS === #
# Common agents used in both scenarios
Sam = Agent(
    role='Social Media Strategist',
    goal='Develop engaging social media and video marketing strategies for the brain chip launch.',
    backstory='Introverted but innovative, enjoys exploring bold content ideas and open to team feedback.',
    llm=custom_llm,
    allow_delegation=False
)

Joe = Agent(
    role='Financial Analyst',
    goal='Ensure the presentation includes compelling financial justifications for the marketing plan.',
    backstory='Highly intelligent and creative with a condescending tone, often clashes with teammates.',
    llm=custom_llm,
    allow_delegation=False
)

Agnus = Agent(
    role='International Marketing Manager',
    goal='Incorporate global appeal and cultural nuances in the marketing presentation.',
    backstory='Culturally sensitive and diplomatic, values equality and global resonance in messaging.',
    llm=custom_llm,
    allow_delegation=False
)

Suzanne = Agent(
    role='Graphic Designer',
    goal='Design a visually appealing concept and theme for the presentation using creative visuals.',
    backstory='Extremely extroverted, passionate about design, thrives in collaborative environments.',
    llm=custom_llm,
    allow_delegation=False
)

# Deviant Agent for Scenario 1
Desmond = Agent(
    role='Product Engineer',
    goal='Explain the brain chip features while actively challenging mainstream ideas to spark innovation.',
    backstory='Outspoken, somewhat neurotic, and intentionally deviant in group settings to test boundaries.',
    llm=custom_llm,
    allow_delegation=False
)

# Control Agent for Scenario 2
Nesmond = Agent(
    role='Product Engineer',
    goal='Explain the brain chip features and collaborate respectfully with the team.',
    backstory='Extraverted and enthusiastic, open-minded and supports group consensus.',
    llm=custom_llm,
    allow_delegation=False
)

# === TASK TEMPLATES === #
def generate_discussion_tasks(agents, round_label):
    return [
        Task(
            description=f"""
            {round_label} Discussion:
            Share your perspective on the presentation direction. 
            React to what other team members have proposed so far (assume you're aware of their general ideas).
            For Desmond only: deliberately challenge ideas, suggest radical alternatives, and test team boundaries.
            For others: You may agree, disagree, or ignore input from others.
            """,
            expected_output="Clear perspective, suggestions, and response to others' inputs.",
            agent=agent
        ) for agent in agents
    ]

# Finalizing the plan
def finalize_task(agent):
    return Task(
        description="""
        Consolidate everyone's contributions from the discussion into a single, cohesive outline for the marketing presentation.
        Be sure to highlight any conflicts resolved, standout ideas adopted, and how final decisions were made.
        """,
        expected_output="Finalized outline of the 30-minute marketing presentation.",
        agent=agent
    )

# === SCENARIO 1: WITH DESMOND (DEVIANT) === #
print("\n--- Running Scenario 1: Desmond as Deviant ---")

crew_scenario_1 = Crew(
    agents=[Sam, Joe, Agnus, Suzanne, Desmond],
    tasks=generate_discussion_tasks([Sam, Joe, Agnus, Suzanne, Desmond], round_label="Round 1: Brainstorming") +
          generate_discussion_tasks([Sam, Joe, Agnus, Suzanne, Desmond], round_label="Round 2: Conflict Resolution") +
          [finalize_task(Joe)],
    process='sequential',
    verbose=True
)

# Generate timestamped filename for the transcript
timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
transcript_filename = f"example_transcript_{timestamp}.txt"

# Redirect stdout to the transcript file
original_stdout = sys.stdout
sys.stdout = open(transcript_filename, 'w')

try:
    print(f"Transcript started at {datetime.now()}\n")
    
    print("=== SCENARIO 1: WITH DESMOND (DEVIANT) ===")
    result_scenario_1 = crew_scenario_1.kickoff()
    print("\nFinal Output for Scenario 1:")
    print(result_scenario_1)
    
    # === SCENARIO 2: CONTROL VERSION (NO DEVIANT) === #
    print("\n\n=== SCENARIO 2: CONTROL (NO DEVIANT) ===")
    
    crew_scenario_2 = Crew(
        agents=[Sam, Joe, Agnus, Suzanne, Nesmond],
        tasks=generate_discussion_tasks([Sam, Joe, Agnus, Suzanne, Nesmond], round_label="Round 1: Brainstorming") +
              generate_discussion_tasks([Sam, Joe, Agnus, Suzanne, Nesmond], round_label="Round 2: Consensus Building") +
              [finalize_task(Joe)],
        process='sequential',
        verbose=True
    )
    
    result_scenario_2 = crew_scenario_2.kickoff()
    print("\nFinal Output for Scenario 2:")
    print(result_scenario_2)

finally:
    # Restore stdout and close the file
    sys.stdout.close()
    sys.stdout = original_stdout

# Print confirmation message to the terminal
print(f"\nScript finished. Full transcript saved to: {transcript_filename}")