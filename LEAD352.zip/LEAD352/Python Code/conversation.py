from langchain.llms import Ollama

# Initialize Ollama with llama3:8b model
llm = Ollama(model="llama3:8b")

def get_user_name():
    return input("Hello! What's your name? ")

def have_conversation():
    # Get the user's name
    name = get_user_name()
    
    # Use llama2 model to generate responses
    response = llm.invoke(f"Generate a friendly greeting for a person named {name}")
    print(response)
    
    # Ask about their day
    feeling = input("How are you feeling today? ")
    response = llm.invoke(f"Generate an empathetic response to someone feeling {feeling}")
    print(response)
    
    # Ask about their hobbies
    hobby = input("What's your favorite hobby? ")
    response = llm.invoke(f"Generate an enthusiastic response about the hobby: {hobby}")
    print(response)
    
    # Ask about their age
    age = input("If you don't mind me asking, how old are you? ")
    response = llm.invoke(f"Generate a positive response about being {age} years old")
    print(response)
    
    # Farewell
    farewell = llm.invoke(f"Generate a warm farewell message for {name}")
    print(f"\n{farewell}")

if __name__ == "__main__":
    have_conversation()