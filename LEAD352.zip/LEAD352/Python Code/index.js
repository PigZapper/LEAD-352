import React from 'react';
import ReactDOM from 'react-dom';
import EscapeRoomSimulation from './Team_project.js';

ReactDOM.render(
  <React.StrictMode>
    <EscapeRoomSimulation />
  </React.StrictMode>,
  document.getElementById('root')
);