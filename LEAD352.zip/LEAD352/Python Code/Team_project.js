import React, { useState, useCallback, useMemo } from "react";
import { Button, Card, CardContent, Typography } from "@mui/material";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, Cell } from "recharts";

// Define personality traits and tasks to ensure clarity and proper variable use
const personalityTraits = ["Openness", "Conscientiousness", "Extraversion", "Agreeableness", "Neuroticism"];

const discussionTasks = [
  { name: "Describe the clue found and propose interpretations", favoredTrait: "Openness" },
  { name: "Discuss potential solutions for the lock mechanism based on available clues", favoredTrait: "Conscientiousness" },
  { name: "Plan the next sequence of actions based on the group’s understanding", favoredTrait: "Agreeableness" },
  { name: "Facilitate creative brainstorming for alternative solutions", favoredTrait: "Openness" },
  { name: "Summarize group decisions and ensure shared understanding", favoredTrait: "Conscientiousness" },
  { name: "Reflect on team collaboration and adjust communication strategies", favoredTrait: "Agreeableness" }
];

const traitAnalysis = {
  Openness: {
    strengths: ["Encourages diverse idea generation", "Open to unconventional solutions", "Promotes brainstorming sessions"],
    weaknesses: ["May prioritize creativity over practicality", "Can divert discussion into tangents"]
  },
  Conscientiousness: {
    strengths: ["Keeps discussion organized and task-focused", "Emphasizes clear plans and stepwise progress"],
    weaknesses: ["May stifle creative suggestions", "Can overly focus on details, delaying decisions"]
  },
  Extraversion: {
    strengths: ["Drives energetic dialogue", "Promotes participation from all members"],
    weaknesses: ["Can dominate conversation", "May rush decisions without full analysis"]
  },
  Agreeableness: {
    strengths: ["Fosters cooperative tone", "Resolves disagreements effectively"],
    weaknesses: ["Avoids necessary conflict", "May yield to others at expense of best solutions"]
  },
  Neuroticism: {
    strengths: ["Highly vigilant about risks", "Brings attention to overlooked problems"],
    weaknesses: ["Can increase group anxiety", "May hesitate to commit to decisions"]
  }
};

const simulateDiscussionQuality = (leaderTrait, task) => {
  let baseScore = 60;
  if (leaderTrait === task.favoredTrait) baseScore += 20;
  return Math.min(100, baseScore + Math.floor(Math.random() * 10) - 5);
};

const analyzeTeamDynamics = (leaderTrait) => {
  switch (leaderTrait) {
    case "Openness":
      return "Leader fostered idea generation through open dialogue, encouraging multiple interpretations of clues.";
    case "Conscientiousness":
      return "Leader emphasized structured discussion and stepwise evaluation, keeping the team task-focused.";
    case "Extraversion":
      return "Leader energized the discussion, promoted participation, but occasionally rushed consensus.";
    case "Agreeableness":
      return "Leader maintained harmony, resolved disagreements, but sometimes avoided necessary debates.";
    case "Neuroticism":
      return "Leader heightened awareness of risks, but increased team stress and decision hesitation.";
    default:
      return "";
  }
};

const generateTranscript = (leaderTrait, discussionScores) => {
  const transcript = [];
  
  discussionTasks.forEach((task, index) => {
    const score = discussionScores[index];
    const quality = score >= 85 ? "excellent" : score >= 70 ? "good" : score >= 55 ? "adequate" : "poor";
    
    // Leader's opening statement
    const leaderOpening = {
      speaker: `Team Leader (${leaderTrait})`,
      text: generateLeaderDialog(leaderTrait, task)
    };
    transcript.push(leaderOpening);
    
    // Team responses based on discussion quality
    const responses = generateTeamResponses(quality, leaderTrait, task);
    transcript.push(...responses);
  });
  
  return transcript;
};

const generateLeaderDialog = (trait, task) => {
  switch (trait) {
    case "Openness":
      return `Let's think creatively about ${task.name}. What unique perspectives can we bring to this?`;
    case "Conscientiousness":
      return `We need to systematically approach ${task.name}. Let's break this down step by step.`;
    case "Extraversion":
      return `Alright team! Let's tackle ${task.name} together! What are your thoughts?`;
    case "Agreeableness":
      return `I'd love to hear everyone's input on ${task.name}. How should we approach this together?`;
    case "Neuroticism":
      return `We need to be careful with ${task.name}. What potential issues should we consider?`;
    default:
      return "";
  }
};

const generateTeamResponses = (quality, leaderTrait, task) => {
  const responses = [];
  const teamMembers = ["Team Member A", "Team Member B", "Team Member C"];
  
  switch (quality) {
    case "excellent":
      teamMembers.forEach(member => {
        responses.push({
          speaker: member,
          text: generateQualityResponse(leaderTrait, task, "excellent")
        });
      });
      break;
    case "good":
      teamMembers.slice(0, 2).forEach(member => {
        responses.push({
          speaker: member,
          text: generateQualityResponse(leaderTrait, task, "good")
        });
      });
      break;
    case "adequate":
      responses.push({
        speaker: teamMembers[0],
        text: generateQualityResponse(leaderTrait, task, "adequate")
      });
      break;
    case "poor":
      responses.push({
        speaker: teamMembers[0],
        text: generateQualityResponse(leaderTrait, task, "poor")
      });
      break;
  }
  
  return responses;
};

const generateQualityResponse = (leaderTrait, task, quality) => {
  const responses = {
    excellent: [
      "That's an excellent point! Building on that idea...",
      "I see how this connects with our previous findings.",
      "This approach aligns perfectly with our goals.",
    ],
    good: [
      "That makes sense, we should consider this approach.",
      "I can work with that suggestion.",
    ],
    adequate: [
      "Okay, that could work.",
      "Maybe we should try that.",
    ],
    poor: [
      "I'm not sure about this...",
      "Can we try something else?",
    ]
  };
  
  return responses[quality][Math.floor(Math.random() * responses[quality].length)];
};

export default function EscapeRoomSimulation() {
  const [simulationIndex, setSimulationIndex] = useState(0);
  const [results, setResults] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);

  const runSimulation = useCallback(() => {
    try {
      setIsLoading(true);
      setError(null);
      const leaderTrait = personalityTraits[simulationIndex];
      const discussionScores = discussionTasks.map(task => simulateDiscussionQuality(leaderTrait, task));
      const teamDynamicSummary = analyzeTeamDynamics(leaderTrait);
      const transcript = generateTranscript(leaderTrait, discussionScores);

      setResults(prev => [
        ...prev,
        { 
          run: simulationIndex + 1, 
          leaderTrait, 
          discussionScores, 
          teamDynamicSummary,
          transcript 
        }
      ]);
      setSimulationIndex(prev => prev + 1);
    } catch (err) {
      setError("Failed to run simulation: " + err.message);
    } finally {
      setIsLoading(false);
    }
  }, [simulationIndex]);

  const averageScores = useMemo(() => 
    results.map(res => ({
      ...res,
      averageScore: res.discussionScores.reduce((a,b)=>a+b,0)/res.discussionScores.length
    })),
    [results]
  );

  const getDiscussionComment = (score) => {
    if (score >= 85) return "Highly effective, insightful discussion.";
    if (score >= 70) return "Good quality discussion.";
    if (score >= 55) return "Adequate discussion, room for improvement.";
    return "Weak discussion, limited collaboration.";
  };

  return (
    <div style={{ padding: "1rem", display: "flex", flexDirection: "column", gap: "1.5rem" }}>
      <Typography variant="h4">Escape Room Team Discussion Simulation</Typography>
      
      {error && (
        <Typography color="error" variant="body1">
          {error}
        </Typography>
      )}
      
      {simulationIndex < personalityTraits.length && (
        <Button 
          variant="contained" 
          onClick={runSimulation}
          disabled={isLoading}
        >
          {isLoading ? "Running Simulation..." : `Run Simulation ${simulationIndex + 1}`}
        </Button>
      )}

      {results.length > 0 && (
        <div style={{ height: "24rem" }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={averageScores}>
              <XAxis dataKey="leaderTrait" />
              <YAxis label={{ value: "Avg Discussion Quality", angle: -90, position: "insideLeft" }} />
              <Tooltip />
              <Legend />
              <Bar dataKey="averageScore" name="Avg Discussion Quality">
                {averageScores.map((entry, index) => (
                  <Cell
                    key={`cell-${index}`}
                    fill={
                      entry.leaderTrait === "Openness" ? "#8884d8" :
                      entry.leaderTrait === "Conscientiousness" ? "#82ca9d" :
                      entry.leaderTrait === "Extraversion" ? "#ffc658" :
                      entry.leaderTrait === "Agreeableness" ? "#a28fd0" :
                      "#ff7f7f"
                    }
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {results.length === personalityTraits.length && (
        <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
          <Typography variant="h5">Discussion Summary</Typography>
          {results.map((res, i) => (
            <Card key={i}>
              <CardContent>
                <Typography variant="h6">Simulation {res.run}: {res.leaderTrait} Leader</Typography>
                <Typography variant="subtitle1">Discussion Quality per Task:</Typography>
                <ul style={{ paddingLeft: "1.5rem" }}>
                  {res.discussionScores.map((score, j) => (
                    <li key={j}>{discussionTasks[j].name}: {score}/100 ({getDiscussionComment(score)})</li>
                  ))}
                </ul>
                <Typography variant="subtitle1">Overall Strengths:</Typography>
                <ul style={{ paddingLeft: "1.5rem" }}>
                  {traitAnalysis[res.leaderTrait].strengths.map((s, j) => (
                    <li key={`s-${j}`}>{s}</li>
                  ))}
                </ul>
                <Typography variant="subtitle1">Overall Weaknesses:</Typography>
                <ul style={{ paddingLeft: "1.5rem" }}>
                  {traitAnalysis[res.leaderTrait].weaknesses.map((w, j) => (
                    <li key={`w-${j}`}>{w}</li>
                  ))}
                </ul>
                <Typography variant="subtitle1">Team Dynamics Analysis: {res.teamDynamicSummary}</Typography>
                <Typography variant="subtitle1">Discussion Transcript:</Typography>
                {res.transcript.map((entry, j) => (
                  <div key={`transcript-${j}`} style={{ marginLeft: "1.5rem", marginBottom: "0.5rem" }}>
                    <Typography variant="body1" style={{ fontWeight: "bold" }}>
                      {entry.speaker}:
                    </Typography>
                    <Typography variant="body2" style={{ marginLeft: "1rem" }}>
                      {entry.text}
                    </Typography>
                  </div>
                ))}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
