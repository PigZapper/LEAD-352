import {
  discussionTasks,
  generateTranscript,
  simulateDiscussionQuality
} from './Team_project';

// Choose a leader trait
const leaderTrait = "Openness";

// Generate discussion scores for each task
const discussionScores = discussionTasks.map(task => simulateDiscussionQuality(leaderTrait, task));

// Generate the transcript
const transcript = generateTranscript(leaderTrait, discussionScores);

// Print the transcript
console.log(`Transcript for ${leaderTrait} Leader:`);
console.log('----------------------------------------');
transcript.forEach(entry => {
  console.log(`${entry.speaker}:`);
  console.log(entry.text);
  console.log('----------------------------------------');
});